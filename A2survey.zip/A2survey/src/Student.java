

public class Student {
	private String sfirst;
	private String slast;
	private String saddress;
	private String zipcode;
	private String city;
	private String state;
	private String telephone;
	private String email;
	private String url;
	private String sdate;
	private String radios;
	private String[] checks;
	private String comments;
	private String chance;
	private String raffle;
	
	public Student(){
		
	}
	
	
	//getter setters
	public String getSfirst() {
		return sfirst;
	}
	public void setSfirst(String sfirst) {
		this.sfirst = sfirst;
	}
	public String getSlast() {
		return slast;
	}
	public void setSlast(String slast) {
		this.slast = slast;
	}
	public String getSaddress() {
		return saddress;
	}
	public void setSaddress(String saddress) {
		this.saddress = saddress;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getSdate() {
		return sdate;
	}
	public void setSdate(String date) {
		this.sdate = date;
	}
	public String getRadios() {
		return radios;
	}
	public void setRadios(String radios) {
		this.radios = radios;
	}
	public String[] getChecks() {
		return checks;
	}
	public void setChecks(String[] checks) {
		this.checks = checks;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getChance() {
		return chance;
	}
	public void setChance(String chance) {
		this.chance = chance;
	}
	public String getRaffle() {
		return raffle;
	}
	public void setRaffle(String raffle) {
		this.raffle = raffle;
	}

}


	
	
	

