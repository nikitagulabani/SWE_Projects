Nikita Sanjay Gulabani
G00912741

/*Below are the links to the home page and survey html*/

S3 index.html url- https://s3.amazonaws.com/swe645nikita/index.html
EC2 survey.html url - http://ec2-52-87-218-28.compute-1.amazonaws.com/A2survey/faces/index.xhtml


