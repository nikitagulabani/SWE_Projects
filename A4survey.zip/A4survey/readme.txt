Nikita Sanjay Gulabani
G00912741

/*Below are the links to the home page, survey page and RESTful service*/
/* I have included the comments in each page, after xml declaration as before that gave me an error*/

S3 index.html url- https://s3.amazonaws.com/swe645nikita/index.html
EC2 survey.html url - http://ec2-52-87-218-28.compute-1.amazonaws.com/ngulaban_hw4/faces/index.xhtml



