Nikita Sanjay Gulabani
G00912741

/*Below are the links to the home page, survey page and RESTful service*/
/* I have included the comments in each page, after xml declaration as before that gave me an error*/

S3 index.html url- https://s3.amazonaws.com/swe645nikita/index.html
EC2 survey.html url - http://ec2-52-87-218-28.compute-1.amazonaws.com/A3survey/faces/index.xhtml
REST API call url-   http://ec2-52-87-218-28.compute-1.amazonaws.com/A3survey/resources/zipcode/22030

Or any other zipcode mentioned in the Homework
In the URL you can change to any of these following zipcodes- 22301, 22312, 22030, 20148.


