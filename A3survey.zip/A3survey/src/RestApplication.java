//This class is created to configure the REST Application
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("resources")
public class RestApplication extends Application {

}
