
package com.swe.niki;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for student complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="student">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="chance" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="check_final" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="city" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="comments" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="email" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="radios" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="raffle" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="saddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="sdate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="sfirst" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="slast" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="start" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="state" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="telephone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="url" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="zipcode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "student", propOrder = {
    "chance",
    "checkFinal",
    "city",
    "comments",
    "email",
    "radios",
    "raffle",
    "saddress",
    "sdate",
    "sfirst",
    "slast",
    "start",
    "state",
    "telephone",
    "url",
    "zipcode"
})
public class Student {

    protected String chance;
    @XmlElement(name = "check_final")
    protected String checkFinal;
    protected String city;
    protected String comments;
    protected String email;
    protected String radios;
    protected String raffle;
    protected String saddress;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar sdate;
    protected String sfirst;
    protected String slast;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar start;
    protected String state;
    protected String telephone;
    protected String url;
    protected String zipcode;

    /**
     * Gets the value of the chance property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChance() {
        return chance;
    }

    /**
     * Sets the value of the chance property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChance(String value) {
        this.chance = value;
    }

    /**
     * Gets the value of the checkFinal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCheckFinal() {
        return checkFinal;
    }

    /**
     * Sets the value of the checkFinal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCheckFinal(String value) {
        this.checkFinal = value;
    }

    /**
     * Gets the value of the city property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCity() {
        return city;
    }

    /**
     * Sets the value of the city property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCity(String value) {
        this.city = value;
    }

    /**
     * Gets the value of the comments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComments() {
        return comments;
    }

    /**
     * Sets the value of the comments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComments(String value) {
        this.comments = value;
    }

    /**
     * Gets the value of the email property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the value of the email property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmail(String value) {
        this.email = value;
    }

    /**
     * Gets the value of the radios property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRadios() {
        return radios;
    }

    /**
     * Sets the value of the radios property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRadios(String value) {
        this.radios = value;
    }

    /**
     * Gets the value of the raffle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRaffle() {
        return raffle;
    }

    /**
     * Sets the value of the raffle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRaffle(String value) {
        this.raffle = value;
    }

    /**
     * Gets the value of the saddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSaddress() {
        return saddress;
    }

    /**
     * Sets the value of the saddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSaddress(String value) {
        this.saddress = value;
    }

    /**
     * Gets the value of the sdate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getSdate() {
        return sdate;
    }

    /**
     * Sets the value of the sdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setSdate(XMLGregorianCalendar value) {
        this.sdate = value;
    }

    /**
     * Gets the value of the sfirst property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSfirst() {
        return sfirst;
    }

    /**
     * Sets the value of the sfirst property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSfirst(String value) {
        this.sfirst = value;
    }

    /**
     * Gets the value of the slast property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSlast() {
        return slast;
    }

    /**
     * Sets the value of the slast property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSlast(String value) {
        this.slast = value;
    }

    /**
     * Gets the value of the start property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getStart() {
        return start;
    }

    /**
     * Sets the value of the start property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setStart(XMLGregorianCalendar value) {
        this.start = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setState(String value) {
        this.state = value;
    }

    /**
     * Gets the value of the telephone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTelephone() {
        return telephone;
    }

    /**
     * Sets the value of the telephone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTelephone(String value) {
        this.telephone = value;
    }

    /**
     * Gets the value of the url property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUrl() {
        return url;
    }

    /**
     * Sets the value of the url property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUrl(String value) {
        this.url = value;
    }

    /**
     * Gets the value of the zipcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getZipcode() {
        return zipcode;
    }

    /**
     * Sets the value of the zipcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setZipcode(String value) {
        this.zipcode = value;
    }

}
