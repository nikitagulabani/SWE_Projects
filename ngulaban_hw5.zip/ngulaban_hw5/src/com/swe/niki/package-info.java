@javax.xml.bind.annotation.XmlSchema(namespace = "http://niki.swe.com/")
package com.swe.niki;
