// StudentBean has attributes that matches most of the Student Survey Form fields, except the Data field
package surveyapp.pkg;

public class Studentbean {

    private String studentid = "";
    private String username = "";
    private String streetaddress = "";
    private String zip = "";
    private String city = "";
    private String state = "";
    private String tel = "";
    private String email = "";
    private String url = "";
    private String sdate = "";
    private String cinput = "";
    private String rinput = "";
    private String comments = "";
    private String gdate = "";
    private String gyear = "";
    private String chance = "";
    private String data = "";

    public String getStudentid() {
        return studentid;
    }

    public void setStudentid(String studentid) {
        this.studentid = studentid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getStreetaddress() {
        return streetaddress;
    }

    public void setStreetaddress(String streetaddress) {
        this.streetaddress = streetaddress;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getSdate() {
        return sdate;
    }

    public void setSdate(String sdate) {
        this.sdate = sdate;
    }

    public String getCinput() {
        return cinput;
    }

    public void setCinput(String cinput) {
        this.cinput = cinput;
    }

    public String getRinput() {
        return rinput;
    }

    public void setRinput(String rinput) {
        this.rinput = rinput;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getGdate() {
        return gdate;
    }

    public void setGdate(String gdate) {
        this.gdate = gdate;
    }

    public String getGyear() {
        return gyear;
    }

    public void setGyear(String gyear) {
        this.gyear = gyear;
    }

    public String getChance() {
        return chance;
    }

    public void setChance(String chance) {
        this.chance = chance;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

}
