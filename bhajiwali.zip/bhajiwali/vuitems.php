 <?php

include 'datalogin.php';
$query = "SELECT * FROM `item` ORDER BY `Iname` ASC";
$rec=mysqli_query($con,$query);

?>

<html>
<head>
<script>
function getvalues(Iid){
	var xmlhttp = null;
		if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
		if(xmlhttp!=null)
		{
			
			var t = "price"+Iid;
			
	
			var iprice = document.getElementById(t).value;
			
		
			
			
			var url = "updateitem.php?itemid="+Iid+"&ip="+iprice;
			xmlhttp.open("GET",url,true);
			xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
			xmlhttp.send();
			
			
		}
		else
		{
			alert("Your browser is not compatible.")
		}
		xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
				var temp="update"+Iid
              
				document.getElementById(temp).value = "Item Updated Successfully";
            }
        };
}
function delvalues(Iid){
	var xmlhttp = null;
		if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
		if(xmlhttp!=null)
		{

			
			var url = "deleteitem.php?itemid="+Iid;
			xmlhttp.open("GET",url,true);
			xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
			xmlhttp.send();
			
			
		}
		else
		{
			alert("Your browser is not compatible.")
		}
		xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
				var temp="delete"+Iid
              
				document.getElementById(temp).value = "Item Deleted Successfully";
				location.reload();
            }
        };
}
function additem(){
	var iname = null;
	var iprice = null;
	var itype = null;
	var url = null;
	var xmlhttp = null;
		if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
		if(xmlhttp!=null)
		{
			
			iname = document.getElementById("iname").value;
			iprice = document.getElementById("iprice").value;
			itype = document.getElementById("itype").value;
			
			if(iname=="")
			{
				alert("Please enter Item Name");
			}
			else if(iprice=="")
			{
				alert("Please enter Item Price");
			}
			else if(itype=="")
			{
				alert("Please enter Item Type");
			}
			else{
			
			url = "insertitem.php?iname="+iname+"&iprice="+iprice+"&itype="+itype;
			xmlhttp.open("GET",url,true);
			xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
			xmlhttp.send();
			}
		}
		else
		{
			alert("Your browser is not compatible.")
		}
		xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
				document.getElementById("depTable").innerHTML = xmlhttp.responseText;
				document.getElementById("infoDiv").innerHTML = "Item Added Successfully";
				document.getElementById("iname").value="";
				document.getElementById("iprice").value="";
				document.getElementById("itype").value="";
				location.reload();
				
            }
        };
}
</script>
</head>
<body bgcolor="#FFFFCC">

<form method="GET">
	<div id="depTable">
	<table id="table1" border="0" cellpadding="0" width="50%">
		<tbody>
		
		<tr>
			<td height="31" width="250"><b>Name</b></td>
			<td align="center" height="31"><b>Price</b></td>
		</tr>
		<tr>
		<?php
		
		while($row=mysqli_fetch_assoc($rec))
		{
			
			echo"<tr>";
			$Iid=$row['Iid'];
		
			
			echo"<td align=\"left\">" .$row['Iname']. "</td>";
			echo"<td align=\"center\">
			<input name=\"oid\" size=\"5\" tabindex=\"5\" type=\"input\" id=\"price$Iid\" value=".$row['IPrice']."> </td>";
			
			echo"<td align=\"center\" ><input id=\"update$Iid\" type=\"button\" onclick='getvalues($Iid)' value=\"Update\"></td>";
			echo"<td align=\"left\" ><input id=\"delete$Iid\" type=\"button\" onclick='delvalues($Iid)' value=\"Delete\"></td>";
	
		
			echo"</tr>";
			echo"<tr></tr>";
			
		}
		?>
		</tr>
	</tbody></table>
	</div>
</form>
<br/>
<br/>
<hr/>
<br/>
<br/>
<form method="GET">
			<table>
			<caption> Add Item </caption>
			<tr><td>Name:</td><td><input type="text" name="iname" id="iname" required></td></tr>
			<tr><td>Price:</td><td><input type="number" name="iprice" id="iprice" required></td></tr>
			<tr><td>Type:</td><td><select name="itype" id="itype">
					<option>Select Type</option>
					<option value="leafy">Leafy</option>
					<option value="other">Other</option>
					</select>
			</td></tr>
					
			<tr><td><input type="button" name="add" id="add" onclick="additem()" value="Add"/><td></tr>
			</table>
			<div id="infoDiv"></div>
		</form>

<p>&nbsp;</p>
<p></p>



</body></html>