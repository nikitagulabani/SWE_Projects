<?php

$cid=$_GET["keyword"];
include 'datalogin.php';

$query = "SELECT `CidPhone` FROM `customer` WHERE `CidPhone` LIKE '%$cid%'";
$rec=mysqli_query($con,$query);

$result=array();
$x=0;
while($row=mysqli_fetch_array($rec)){
	$result[$x]=$row['CidPhone'];
	$x++;
}

echo json_encode($result);

?>
	


