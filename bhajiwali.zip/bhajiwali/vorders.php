<?php

include 'datalogin.php';
#$query = "SELECT `Oid`,`CidPhone`,`Cfirst`, `Clast`, `CAddress` FROM `order` INNER JOIN `customer` ON customer.Cid=order.Cid";
$query = "SELECT `Oid`,`Cfirst`, `Clast`, `CAddress` FROM `order`,`customer` WHERE customer.CidPhone=order.CidPhone";


$rec=mysqli_query($con,$query);


?>
<html>
<head>
<script>
function printDiv(divName) {
    var printContents = document.getElementById(divName).innerHTML;
    var originalContents = document.body.innerHTML;
    document.body.innerHTML = printContents;
    window.print();
    document.body.innerHTML = originalContents;
}
</script>

</head>

<body bgcolor="#FFFFCC">
<div id="printableArea">

<h2>BhajiWali-Sabse Fresh</h2>


	<p>Orders:</p>
	<table id="table2" border="2px" cellpadding="12px" width="50%">
		<tbody><tr>
			<td><b>Order ID</b></td>
			<td><b>First </b></td>
			<td><b>Last</b></td>
			<td><b>Address</b></td>
		</tr>
		<tr>
		
		<?php
		
		while($row=mysqli_fetch_assoc($rec))
		{
			
			echo"<tr>";
			echo"<td> <a href=\"bill.php?oid=".$row['Oid']."\">".$row['Oid']."</a></td>";
			echo"<td>" .$row['Cfirst']. "</td>";
			echo"<td>" .$row['Clast']. "</td>";
			echo"<td>" .$row['CAddress']. "</td>";
			
			
			echo"</tr>";
			
		}
		?>
		</table>
		
		</tr>
		<tr>
			<td width="250">&nbsp;</td>
			<td align="center" width="100">&nbsp;</td>
			<td align="right" width="60">&nbsp;</td>
			<td align="right" width="140">&nbsp;</td>
		</tr>
		<tr>
		
		</tr>
		<tr>
			<td width="250">&nbsp;</td>
			<td align="center" width="100">&nbsp;</td>
			<td align="right" width="60">&nbsp;</td>
			<td align="right" width="140">&nbsp;</td>
		</tr>
	</tbody></table>
	<p>&nbsp;</p>
</div>	
	<form>
	<input type="button" onclick="printDiv('printableArea')" value="PRINT PDF" />
</form>




<p>&nbsp;</p>
<p></p>



</body></html>