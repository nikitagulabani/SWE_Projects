<?php

include 'datalogin.php';
$query = "SELECT * FROM `order` WHERE `Status`=\" \" ORDER BY date desc";
$rec=mysqli_query($con,$query);

?>

<html>
<head>
<script>
function getvalues(oid){
	var xmlhttp = null;
		if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
		if(xmlhttp!=null)
		{
		
			var t1 = "at"+oid;
			var t2 = "s"+oid;
	
			var atotal = document.getElementById(t1).value;
			var status = document.getElementById(t2).value;
			
			
			
			var url = "updaterecord.php?uid="+oid+"&at="+atotal+"&sta="+status;
			xmlhttp.open("GET",url,true);
			xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
			xmlhttp.send();
			
			
		}
		else
		{
			alert("Your browser is not compatible.")
		}
		xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
				var t3 = "update"+oid
				document.getElementById(t3).value = "Order Updated Successfully";
            }
        };
}
</script>
</head>
<body bgcolor="#FFFFCC">

<form method="GET">
	<table id="table1" border="0" cellpadding="0" width="60%">
		<tbody>
		
		<tr>
			<td height="31" width="250"><b>Order ID</b></td>
			<td align="center" height="31" width="15%"><b>Client ID</b></td>
			<td align="right" height="31" width="15%"><b>Staff ID </b></td>
			<td align="right" height="31" width="15%"><b>Date</b></td>
			<td align="center" height="31" width="15%"><b>Estimated Total</b></td>
			<td align="right" height="31" width="15%"><b>Actual Total</b></td>
			<td align="right" height="31" width="10%"><b>Status</b></td>
		</tr>
		<tr>
		<?php
		
		while($row=mysqli_fetch_assoc($rec))
		{
			$oid=$row['Oid'];
			
			echo"<tr>";
			echo"<td> <a href=\"editorder.php?oid=".$row['Oid']."\">".$row['Oid']."</a></td>";
			echo"<td align=\"center\">" .$row['CidPhone']. "</td>";
			echo"<td align=\"right\">" .$row['Sid']. "</td>";
			echo"<td align=\"right\">" .$row['Date']. "</td>";
			echo"<td align=\"center\">" .$row['ETotal']. "</td>";
			echo"<td align=\"center\">
			<input size=\"5\" tabindex=\"5\" type=\"input\" id=\"at$oid\" value=\"0\"></td>";
			echo"<td align=\"center\" >
			<input id=\"s$oid\" size=\"5\" tabindex=\"5\" type=\"input\"> </td>";
			echo"<td align=\"center\" ><input id=\"update$oid\" type=\"button\" onclick='getvalues($oid)' value=\"Update\"></td>";
	
		
			echo"</tr>";
			echo"<tr></tr>";
			
		}
		?>
		</tr>
	</tbody></table>
</form>
</body>
</html>