<?php

include 'datalogin.php';
$iname=$_GET['iname'];
$iprice=$_GET['iprice'];
$itype=$_GET['itype'];

$query = "INSERT INTO `bhajiwali`.`item` (`Iid`, `Iname`, `IPrice`, `Itype`) VALUES (NULL, '$iname', $iprice, '$itype')";
mysqli_query($con,$query);

$query1 = "SELECT * FROM `item`";
$rec1=mysqli_query($con,$query1);

?>
				<div id="depTable">
	<table id="table1" border="0" cellpadding="0" width="50%">
		<tbody>
		
		<tr>
			<td height="31" width="250"><b>Name</b></td>
			<td align="center" height="31"><b>Price</b></td>
		</tr>
		<tr>
		<?php
		
		while($row1=mysqli_fetch_assoc($rec1))
		{
			
			echo"<tr>";
			$Iid=$row1['Iid'];
		
			
			echo"<td align=\"left\">" .$row1['Iname']. "</td>";
			echo"<td align=\"center\">
			<input name=\"oid\" size=\"5\" tabindex=\"5\" type=\"input\" id=\"price$Iid\" value=".$row1['IPrice']."> </td>";
			
			echo"<td align=\"left\" ><input id=\"update$Iid\" type=\"button\" onclick='getvalues($Iid)' value=\"Update\"></td>";
			
	
		
			echo"</tr>";
			echo"<tr></tr>";
			
		}
		
		
			

mysqli_close($con);
?>