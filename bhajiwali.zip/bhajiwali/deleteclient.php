<?php

include 'datalogin.php';
$cid=$_GET['cid'];

$query = "DELETE FROM `customer` WHERE `CidPhone`=$cid";
mysqli_query($con,$query);
mysqli_close($con);
?>