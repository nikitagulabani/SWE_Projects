<?php
include 'datalogin.php';

$query = "SELECT * FROM `order` o, `customer` c where o.Date = Date(NOW()) and o.CidPhone = c.CidPhone";



$rec=mysqli_query($con,$query);

?>
<html>
<head>
 <link rel="stylesheet" href="style/jquery-ui.css"/>
<link rel="stylesheet" href="style/jquery-ui.structure.css"/>
<script src="script/jquery.js"></script>
<script src="script/jquery-ui.js"></script>


<script>
 //button- input & go back
  $(function() {
    $( ".button" )
      .button(
	  //icon applies to anchor and button bot input elements
		{
			icons: {
			primary: "ui-icon ui-icon-arrowreturnthick-1-w"
		},
      text: true
		});
		
  });
</script>
<script>
function printDiv(divName) {
    var printContents = document.getElementById(divName).innerHTML;
    var originalContents = document.body.innerHTML;
    document.body.innerHTML = printContents;
    window.print();
    document.body.innerHTML = originalContents;
}
</script>


<title>Bhaji Wali&nbsp; - Sabse Fresh!</title>
<style>
table, th, td {
     border: 1px solid black;
	 
	 
}

</style>

</head>

<body bgcolor="#FFFFCC">
<div id="printableArea">
<h2>BhajiWali-Sabse Fresh</h2>

<br>
<h4>Orders for Today</h4>

<p id="demo"></p>

		<script>
		var dateObj = new Date();
		var month = dateObj.getUTCMonth() + 1; //months from 1-12
		var day = dateObj.getUTCDate();
		var year = dateObj.getUTCFullYear();

		newdate = day + "/" +'0'+ month + "/" + year;
		document.getElementById("demo").innerHTML = "Date:"+" "+newdate;
		</script>

<table>
<tr>
<td>	

		
		<?php
		
		//------------------------------Calculations----------------------------------------------
		$counter = 1;
		$rec1=mysqli_query($con,$query);
		
		while($row=mysqli_fetch_assoc($rec1))
		{
			$type=$row['Ctype'];
			if ($type=="premium") //Calc Total Deposit
			{
	
			$DepositQuery="SELECT `ADDate`, `Deposit` FROM `advanceddeposit` WHERE advanceddeposit.CidPhone=".$row['CidPhone'];
			$DepositResult=mysqli_query($con,$DepositQuery);
		//Use sum in query
			$sum=0;
			while($dep=mysqli_fetch_assoc($DepositResult))
			{
			//get deposit
			$d=$dep['Deposit'];
			//calc total deposit
			$sum+=$d;
			
			}
			//echo"Total Deposit:".$sum;
			}
			else{ // Not Premium 
				$sum=0;  //No Deposit
				//echo"Total Deposit:".$sum;
			}
			
			//--------------------Calc total sales and balance
			$totalsales=0;
			$TotalSalesQuery = "SELECT `ATotal` FROM `order` WHERE CidPhone=".$row['CidPhone']." and Date < CURDATE()";
			$TotSalaryResult=mysqli_query($con,$TotalSalesQuery);
			while($totSalrow=mysqli_fetch_assoc($TotSalaryResult))
			{
			
				$atotal=$totSalrow['ATotal'];
				//echo"Actual Total".$atotal;
			
				$totalsales+=$atotal;
				
			
			}
			
			$bal=0;
			//echo"Total Sales:".$totalsales;
			
			if($type=="premium")
			{
				$bal=$sum-$totalsales;
			}
			
			//echo"Balance:".$bal;
			//------------------------------Done Calculations----------------------------------
			
			//--------------------------Display Info-----------------------------------------
			echo"<table>";
			echo"<tr>";
			//client details
			echo"<td>";
			$orderId = $row['Oid'];
			$thisAtotal= $row['ATotal'];
			echo"<br>";
			echo"<b>Order Id:</b>" .$counter;
			echo"<br>";
			echo"<b>Name:</b>" .$row['Cfirst']." ".$row['Clast'];
			echo"<br>";
			echo"<b>Type:</b>" .$row['Ctype'];
			echo"<br>";
			echo"<b>Phone No.:</b>" .$row['CidPhone'];
			echo"<br>";
			echo"<b>Address:</b>" .$row['CAddress'];
			echo"</td>";
			
			//balance
			
			
			echo"<td>";
			echo"<b>Balance:</b>" .$bal;
			echo"<br>";
			echo"<b>Bill Amount:</b>" .$thisAtotal;
			echo"<br>";
			echo"<b>Available:</b>" .($bal-$thisAtotal);
			echo"<br>";
			echo"</td>";
			echo"</tr>";
			echo"</tbody>";
			echo"</table>";
		
			$counter++;
		}
		?>
		
		
		
	</td>
	
	</tr>
	</table>
	</div>
	<br/>
	<form>
	<table>
	<tr>
	<td><input type="button" onclick="printDiv('printableArea')" value="PRINT" class="button"/></td>
	<td><a href="admindashboard.php" class="button">Go Back</a></td>
	</tr>
	</table>
	</form>
</body></html>