 <?php

include 'datalogin.php';
$name=$_POST['name'];
$username=$_POST['username'];
$password=$_POST['password'];
$phone=$_POST['phone'];

$query = "INSERT INTO `staff`(`Sname`, `Susername`, `Spassword`, `Sphone`) VALUES ('$name','$username','$password',$phone)";

mysqli_query($con,$query);

$_SESSION['message'] = 'Staff Registered Successfully';
if (isset($_SESSION['message'])) {
  echo $_SESSION['message'];
  unset($_SESSION['message']);
}
mysqli_close($con);
echo "<br/><a href='admindashboard.php'>Register New Staff</a>";
?>
