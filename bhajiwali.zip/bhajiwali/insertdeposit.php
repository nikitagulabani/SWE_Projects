<?php

include 'datalogin.php';
$cid=$_GET['cid'];
$deposit=$_GET['deposit'];
$date=$_GET['date'];

$query = "INSERT INTO `bhajiwali`.`advanceddeposit` (`ADId`, `CidPhone`, `ADDate`, `Deposit`) VALUES (NULL, '$cid', '$date', $deposit)";
mysqli_query($con,$query);

$query3="SELECT `ADDate`, `Deposit` FROM `advanceddeposit` WHERE advanceddeposit.CidPhone=$cid";
$rec3=mysqli_query($con,$query3);

?>
			<div id="depTable">
			<table id="table4" border="2px" cellpadding="12px" width="50%">
			<caption> Deposit Table </caption>
		<tbody><tr>
			<td><b>Date </b></td>
			<td><b>Deposit</b></td>

		</tr>
		<tr>
			<?php
			$sum=0;
			while($row3=mysqli_fetch_assoc($rec3))
			{
			$d=$row3['Deposit'];
			
			echo"<tr>";
			echo"<td>".$row3['ADDate']."</td>";
			echo"<td>".$d."</td>";
			$sum+=$d;
			echo"</tr>";
			
			}
			echo "</table></div>";
			echo"<span><b>Total Deposit:</b>".$sum."</span>";
			

mysqli_close($con);
?>