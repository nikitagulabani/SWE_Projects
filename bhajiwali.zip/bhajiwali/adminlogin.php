<?php
session_start();
$message="";
if(count($_POST)>0) {
include 'datalogin.php';
$username = $_POST['userName'];

$password = $_POST['password'];

$sql = "SELECT * FROM `admin` WHERE `ausername` = '$username' and `apassword` = '$password'";

$result = mysqli_query($con,$sql);

if($result === FALSE) { 
    echo "Cannot execute the query"; // TODO: better error handling
}
$row=mysqli_fetch_array($result,MYSQLI_ASSOC);
if(is_array($row)) {
$aid=$row['aid'];
$username=$row['ausername'];
$_SESSION["aid"] = $aid ;
$_SESSION["username"] = $username ;
} else {
$message = "Invalid Username or Password!";
}
}
if(isset($_SESSION["aid"])) {
header("Location:admindashboard.php");
}
?>
<html>
<head>
<title>User Login</title>
<link rel="stylesheet" type="text/css" href="style/styles.css" />
</head>
<body bgcolor="#FFFFCC">

<h2>BhajiWali-Sabse Fresh</h2>
<h3> Admin Login <h3>
<br>
<form name="frmUser" method="post" action="">
<div class="message"><?php if($message!="") { echo $message; } ?></div>
<table border="0" cellpadding="10" cellspacing="1" width="500" align="center">
<tr class="tableheader">
<td align="center" colspan="2">Enter Login Details</td>
</tr>
<tr class="tablerow">
<td align="right">Username</td>
<td><input type="text" name="userName" autofocus></td>
</tr>
<tr class="tablerow">
<td align="right">Password</td>
<td><input type="password" name="password"></td>
</tr>
<tr class="tableheader">
<td align="center" colspan="2"><input type="submit" name="submit" value="Submit"></td>
</tr>
</table>
</form>
</body></html>