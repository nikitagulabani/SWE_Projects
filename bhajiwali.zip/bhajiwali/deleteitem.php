<?php

include 'datalogin.php';
$Iid=$_GET['itemid'];

$query = "DELETE FROM `item` WHERE `Iid`=$Iid";
mysqli_query($con,$query);
mysqli_close($con);
?>