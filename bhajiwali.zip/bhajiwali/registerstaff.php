<html>
<head>
<title>Register Staff
</title>
</head>
<body>
<p>Enter Staff Info:</p>

<form method="POST" action="insertstaff.php" >
	<table id="table1" border="0" cellpadding="0" width="550">
		<tbody>
		<tr>
			<td align="right" width="340">*Name:</font></td>
			<td width="10">&nbsp;</td>
			<td width="200"><input name="name" size="30" tabindex="1" type="text" required autofocus></td>
		</tr>
		<tr>
			<td align="right" width="340">*Username:</font></td>
			<td width="10">&nbsp;</td>
			<td width="200"><input name="username" size="30" tabindex="1" type="text" required></td>
		</tr>
		
		<tr>
			<td align="right" width="340">*Password:</td>
			<td width="10">&nbsp;</td>
			<td width="200"><input type="password" size="30" tabindex="1" name="password" required></td>
		</tr>
		<tr>
			<td align="right" width="340">*Phone:</font></td>
			<td width="10">&nbsp;</td>
			<td width="200"><input name="phone" size="30" tabindex="1" type="tel" required></td>
		</tr>
		<tr>
			<td align="right" width="340">&nbsp;</td>
			<td width="10">&nbsp;</td>
			<td width="200">&nbsp;</td>
		</tr>
	</tbody></table>
	<table id="table3" border="0" cellpadding="0" width="550">
		<tbody><tr>
			<td width="563">
			<p align="center">
			<input value="Register" name="subButton" tabindex="50" type="submit">&nbsp;&nbsp;&nbsp;&nbsp; 
			<input value="Reset" name="resetButton" tabindex="50" type="reset"></p></td>
		</tr>
	</tbody></table>
</form>

<p>&nbsp;</p>
<p></p>

</body>
</html>