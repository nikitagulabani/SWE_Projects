<?php
session_start();
include 'datalogin.php';
$oid=$_POST['orderid'];
$date=$_POST['date'];
$sid=$_POST['sid'];
$cidphone=$_POST['cidphone'];
$GrandTotal=$_POST['total'];

$query = "UPDATE `order` SET `CidPhone`=$cidphone,`Sid`=$sid,`Date`=$date,`ETotal`=$GrandTotal WHERE order.Oid=$oid";

mysqli_query($con,$query);

	
$query2="SELECT DISTINCT item.Iid,`Iname`,`IPrice`,`Qty` FROM `orderitem`,`order`,`item` WHERE orderitem.Oid=$oid AND orderitem.Iid=item.Iid";
$rec1=mysqli_query($con,$query2);
while($row1=mysqli_fetch_assoc($rec1))
		{
			
			$Iid=$row1['Iid'];
			$test = 'q'.$Iid;
			$qty=$_POST[$test];
			if($qty != 0){
				
				$ins="UPDATE `orderitem` SET `Iid`=$Iid,`Qty`=$qty WHERE orderitem.Oid=$oid";
				//echo $ins;
				//die();
				mysqli_query($con,$ins);
			}
			
		}
		
	//echo ($oid);
$_SESSION['message'] = 'Order Edited Successfully';
if (isset($_SESSION['message'])) {
  echo $_SESSION['message'];
  unset($_SESSION['message']);
}
mysqli_close($con);
?>
<html>
<body bgcolor="#FFFFCC">

<br/>
<a href="admindashboard.php">Edit Another Order</a>
<br/>
<a href="index.php">Logout</a>

</body>
</html>