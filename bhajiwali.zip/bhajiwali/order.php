<!Doctype html>
<?php
session_start();
include 'datalogin.php';
$query = "SELECT * FROM `item` ORDER BY `Iname` ASC ";

$rec=mysqli_query($con,$query);
$Sid=$_SESSION["Sid"];
$username=$_SESSION["username"];
echo "Welcome $username"." "."<a href='index.php' class=\"button-logout\">Logout</a>"." "."<a href='staffregistercustomer.php' class=\"button-register\">Register Customer</a>";

?>
<html>
<head>
<link rel="stylesheet" href="style/styles.css"/>
<link rel="stylesheet" href="style/autocomplete.css"/>
<link rel="stylesheet" href="style/jquery-ui.css"/>
<link rel="stylesheet" href="style/jquery-ui.structure.css"/>
<script src="script/jquery.js"></script>
<script src="script/jquery-ui.js"></script>

<script>
//tooltip
$(function(){
	$(document).tooltip();
});
</script>
<script>
//Datepicker
/*$(function(){
	$("#datep").datepicker({dateFormat: 'yy-mm-dd'}); //coz mysql takes this format else inserts 0000-00-00
});*/

	function setDate(){
		var dateObj = new Date();
		var month = dateObj.getUTCMonth() + 1; //months from 1-12
		var day = dateObj.getUTCDate();
		var year = dateObj.getUTCFullYear();

		newdate = year + "/" + '0'+month + "/" + day;
		document.getElementById("datep").value = newdate;
	}
</script>
<script>
//autocomplete for cidphone
var MIN_LENGTH = 2;

$( document ).ready(function() {
	$("#cidphone").keyup(function() {
		var cidphone = $("#cidphone").val();
		if (cidphone.length >= MIN_LENGTH) {
			$.get("autocomplete.php", { keyword: cidphone } )
			
			.done(function( data ) {
				$('#results').html('');
				var results = JSON.parse(data);
				console.log(results);
				$(results).each(function(index, value) {
					$('#results').append('<div class="item">'+value+'</div>');
				})

			    $('.item').click(function() {
			    	var text = $(this).html();
			    	$('#cidphone').val(text);
			    })

			});
		} else {
			$('#results').html('');
		}
	});

    $("#cidphone").blur(function(){
    		$("#results").fadeOut(500);
    	})
        .focus(function() {		
    	    $("#results").show();
    	});

});
</script>
 <script>
 //button- input type submit
  $(function() {
    $( ".button" )
      .button();
  });
</script>
   <script>
 //button- logout
  $(function() {
    $( ".button-logout" )
      .button(
	  //icon applies to anchor and button bot input elements
		{
			icons: {
			primary: "ui-icon ui-icon-power"
		},
      text: true
		});
  });
  </script>
  
  <script>
 //button- logout
  $(function() {
    $( ".button-register" )
      .button(
	  //icon applies to anchor and button bot input elements
		{
			icons: {
			primary: "ui-icon ui-icon-person"
		},
      text: true
		});
  });
  </script>
<script>
//to avoid submit on enter
$(document).ready(function() {
  $(window).keydown(function(event){
    if(event.keyCode == 13) {
      event.preventDefault();
      return false;
    }
  });
});
</script>
<script>
//to check fields
function testChange(counter){

var a=document.getElementById("datep").value;
var b=document.getElementById("cidphone").value;

if ((a==null || a=="") && (b==null || b==""))
  {
  alert("All Field must be filled out");
  return false;
  }
if (a==null || a=="")
  {
  alert("Date must be filled out");
  return false;
  }
if (b==null || b=="")
  {
  alert("Client Phone number must be filled out");
  return false;
  }

	var test = "q"+counter;
	var test2 = "t"+counter;
	var test3 = "p"+counter;
	var quantity = document.getElementById(test).value;
	var price = document.getElementById(test3).value;
	var total = quantity * price;
	document.getElementById(test2).value = total;
	
	var grandtotal = 0.0;
	<?php while($row=mysqli_fetch_assoc($rec)){
		$testval = $row['Iid'];
		?>
		var gt = "t"+<?php echo $testval; ?>;
		grandtotal += parseFloat(document.getElementById(gt).value);
	<?php
	}
	?>
	document.getElementById("total").value = grandtotal;
}
</script>
<script>
function getValue(cuser){
	
		var xmlhttp = null;
		if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
		if(xmlhttp!=null)
		{
			
			
			var url = "tofetchdata.php?val="+cidphone.value;
			xmlhttp.open("GET",url,true);
			xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
			xmlhttp.send();
			
			
		}
		else
		{
			alert("Your browser is not compatible.")
		}
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                var response = (xmlhttp.responseText).split(';');
				var first = response[1];
				var last = response[2];
				var address = response[3];
				
				if(cidphone=="")
				{
					alert("No such Username exists, Please enter valid Username")
					
					document.getElementById("first").value = "";
					document.getElementById("last").value = "";
					document.getElementById("address").value = "";
				}
				else
				{
				//document.getElementById("cid").value = cid;
				document.getElementById("first").value = first;
				document.getElementById("last").value = last;
				document.getElementById("address").value = address;
				}
            }
        };
        
       

    
}
        </script>
<title>Bhaji Wali&nbsp; - Sabse Fresh!</title>

</head>

<body bgcolor="	FFFFF0" onload="setDate()">

<h2>BhajiWali-Sabse Fresh</h2>
<br>

<p><b><i>Enter Coustomer Info:</i><b></p>


<form method="POST" action="submit.php" name="ofrm">
	
			<table id="table1" border="0" cellpadding="4">
		<tbody class="tablerow">
		<tr>
			<td align="right">*Date:</font></td>
			<td width="200"><input type="text" name="datep" id="datep" required></td>
		</tr>
		<tr>
			<td align="right">*Staff ID:</font></td>
			<td width="200"><input type="text" name="sid" id="sid" value="<?php echo $Sid; ?>" required></td>
		</tr>
		<tr>
			<td align="right">*CID/Phone:</font></td>
			<td width="200"><input name="cidphone" type="tel" id="cidphone" onmouseover="getValue(this)" required autofocus></td>
			<td><div id="results"></div></td>
			
		</tr>
		<tr>
			<td align="right">First:</font></td>
			<td width="200"><input name="first" type="text" id="first" readonly></td>
		</tr>
		<tr>
			<td align="right">Last:</font></td>
			<td width="200"><input name="last" type="text" id="last" readonly></td>
		</tr>

		<tr>
			<td align="right">Address:</td>
			<td width="200"><input type="address" type="text" id="address" name="address"></td>
		</tr>
		</tbody>
		</table>
			
	
	
	<p><b><i>Tell us what you would like to order today:<i><b></p>
	<table id="table2" border="0" cellpadding="4">
		<tbody><tr class="tableheader">
			<th width="25%"><b>Item</b></th>
			<th width="25%"><b>Qty/Weight</b></th>
			<th width="25%"><b>Price/Unit </b></th>
			<th width="25%"><b>Total</b></th>
		</tr>
		<?php
		$counter = 0;
		$rec1=mysqli_query($con,$query);
		while($row=mysqli_fetch_assoc($rec1))
		{
			$counter = $row['Iid'];
			echo"<tr class=\"tablerow\">";
			echo"<td>" .$row['Iname']. "</td>";
			echo"<td>
			<input id=\"q$counter\" name=\"q$counter\" class=\"qty\" title=\"Enter as follows, Eg: 0.25 for 250gm or 1 for 1Kg/Item\" type=\"input\" value=\"0\" onchange=\"testChange($counter)\"></td>";
			echo"<td>
			<input id=\"p$counter\" class=\"price\" title=\"Price is as per unit or quantity i.e 1 Kg\" type=\"input\" value=".$row['IPrice']." readonly> </td>";
			echo"<td>
			<input id=\"t$counter\" name=\"ttotal\" type=\"text\" value=\"0\" readonly></td>";
			
			echo"</tr>";
			//$counter++;
		}
		?>
		<tr class="tableheader">
			<th colspan="3" align="right"><b>TOTAL:</b></th>
			<td><input id="total" name="total" size="15" tabindex="99" type="text" readonly></td>
		</tr>
	</tbody></table>
	<p>&nbsp;</p>

			
			<input value="Submit" name="subButton" id="subButton" type="submit" class="button"/>
			</form>


</body>
</html>