<?php

include 'datalogin.php';
$query = "SELECT * FROM `customer` ORDER BY `Cfirst` ASC";
$rec=mysqli_query($con,$query);

$query1="SELECT order.CidPhone,`Ctype`, `Cfirst`, `Clast`, `CAddress`,`Oid`,MAX(`Date`),DATEDIFF(CURDATE(),MAX(Date)) FROM `order`, `customer` WHERE DATEDIFF(CURDATE(),Date)>=3 AND customer.CidPhone=order.CidPhone GROUP BY order.CidPhone";
$rec1=mysqli_query($con,$query1);


?>
<html>
<head>
<script>
function delvalues(Cid){
	var xmlhttp = null;
		if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
		if(xmlhttp!=null)
		{

			
			var url = "deleteclient.php?cid="+Cid;
			xmlhttp.open("GET",url,true);
			xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
			xmlhttp.send();
			
			
		}
		else
		{
			alert("Your browser is not compatible.")
		}
		xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
				var temp="delete"+Cid
              
				document.getElementById(temp).value = "Item Deleted Successfully";
				location.reload();
            }
        };
}
</script>

</head>

<body bgcolor="#FFFFCC">

<h2>BhajiWali-Sabse Fresh</h2>


	
	<table id="table2" border="2px" cellpadding="12px" width="50%">
	<caption>Client Information</caption>
		<tbody><tr>
			<td><b>Client ID/Phone</b></td>
			<td><b>Client Type</b></td>
			<td><b>First </b></td>
			<td><b>Last</b></td>
			<td><b>Address</b></td>
		</tr>
		<tr>
		
		<?php
		
		while($row=mysqli_fetch_assoc($rec))
		{
			$Cid=$row['CidPhone'];
			echo"<tr>";
			echo"<td> <a href=\"client.php?cid=".$row['CidPhone']."&type=".$row['Ctype']."\">".$row['CidPhone']."</a></td>";
			echo"<td>" .$row['Ctype']. "</td>";
			echo"<td>" .$row['Cfirst']. "</td>";
			echo"<td>" .$row['Clast']. "</td>";
			echo"<td>" .$row['CAddress']. "</td>";
			echo"<td align=\"left\" ><button id=\"delete$Cid\" onclick='delvalues($Cid)'>Delete Client</button></td>";
			
			
			echo"</tr>";
			
		}
		?>
		</table>
		<br/>
		<br/>
		<hr/>
		<br/>
		<br/>
		
		<table id="table2" border="2px" cellpadding="12px" width="50%">
			<caption>Clients with no order from past 3 days</caption>
		<tbody><tr>
			<td><b>Client ID/Phone</b></td>
			<td><b>Client Type</b></td>
			<td><b>First </b></td>
			<td><b>Last</b></td>
			<td><b>Address</b></td>
			<td><b>Order ID </b></td>
			<td><b>Date</b></td>
			<td><b>Date Gap</b></td>
		</tr>
		<tr>
		
		<?php
		
		while($row1=mysqli_fetch_assoc($rec1))
		{
			
			echo"<tr>";
			echo"<td> <a href=\"client.php?cid=".$row1['CidPhone']."&type=".$row['Ctype']."\">".$row1['CidPhone']."</a></td>";
			echo"<td>" .$row1['Ctype']. "</td>";
			echo"<td>" .$row1['Cfirst']. "</td>";
			echo"<td>" .$row1['Clast']. "</td>";
			echo"<td>" .$row1['CAddress']. "</td>";
			echo"<td>" .$row1['Oid']. "</td>";
			echo"<td>" .$row1['MAX(`Date`)']. "</td>";
			echo"<td>" .$row1['DATEDIFF(CURDATE(),MAX(Date))']. "</td>";
			
			
			
			echo"</tr>";
			
		}
		?>
		</table>
		
		</tr>
		<tr>
			<td width="250">&nbsp;</td>
			<td align="center" width="100">&nbsp;</td>
			<td align="right" width="60">&nbsp;</td>
			<td align="right" width="140">&nbsp;</td>
		</tr>
		<tr>
		
		</tr>
		<tr>
			<td width="250">&nbsp;</td>
			<td align="center" width="100">&nbsp;</td>
			<td align="right" width="60">&nbsp;</td>
			<td align="right" width="140">&nbsp;</td>
		</tr>
	</tbody></table>
	<p>&nbsp;</p>
	
</form>


<p>&nbsp;</p>
<p></p>



</body></html>