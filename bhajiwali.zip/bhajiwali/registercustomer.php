<html>
<head>
<title>Register Customer
</title>
<link rel="stylesheet" href="style/jquery-ui.css"/>
<link rel="stylesheet" href="style/jquery-ui.structure.css"/>
<script src="script/jquery.js"></script>
<script src="script/jquery-ui.js"></script>
<script>
$(function(){
	$("#datepicker").datepicker({dateFormat: 'yy-mm-dd'});
});
</script>
<script>
function setzero() {
    var x = document.getElementById("ctype").value;
	
	if(x=="regular")
	{
		document.getElementById("amount").value = 0.0;
	}
    
}
</script>
</head>
<body><p>Enter Coustomer Info:</p>

<form method="POST" action="insertcustomer.php" name="cregister">
	<table id="table1" border="0" cellpadding="0" width="550">
		<tbody>
		<tr>
			<td align="right" width="340">*CID/Phone:</font></td>
			<td width="10">&nbsp;</td>
			<td width="200"><input name="cidphone" size="30" tabindex="1" type="tel" required autofocus></td>
		</tr>
		
		<tr>
			<td align="right" width="340">Date:</font></td>
			<td width="10">&nbsp;</td>
			<td width="200"><input type="text" name="datepicker" size="30" tabindex="1" id="datepicker" required></td>
		</tr>
		<tr>
			<td align="right" width="340">Client Type:</font></td>
			<td width="10">&nbsp;</td>
			<td width="200">
			<select name="ctype" id="ctype" onblur='setzero()'>
					<option>Select Type</option>
					<option value="regular">Regular</option>
					<option value="premium">Premium</option>
			</select>
			</td>
		</tr>
		<tr>
			<td align="right" width="340">*First:</font></td>
			<td width="10">&nbsp;</td>
			<td width="200"><input name="first" size="30" tabindex="1" type="text" required></td>
		</tr>
		<tr>
			<td align="right" width="340">*Last:</font></td>
			<td width="10">&nbsp;</td>
			<td width="200"><input name="last" size="30" tabindex="1" type="text" required></td>
		</tr>
		
		<tr>
			<td align="right" width="340">*Address:</td>
			<td width="10">&nbsp;</td>
			<td width="200"><input type="address" size="30" tabindex="1" name="address" required></td>
		</tr>
		
		<tr>
			<td align="right" width="340">Advanced Deposit:</font></td>
			<td width="10">&nbsp;</td>
			<td width="200"><input name="amount" id="amount" size="30" tabindex="1" type="number"></td>
		</tr>
		<tr>
			<td align="right" width="340">&nbsp;</td>
			<td width="10">&nbsp;</td>
			<td width="200">&nbsp;</td>
		</tr>
	</tbody></table>
	<table id="table3" border="0" cellpadding="0" width="550">
		<tbody><tr>
			<td width="563">
			<p align="center">
			<input value="Register" name="subButton" tabindex="50" type="submit">&nbsp;&nbsp;&nbsp;&nbsp; 
			<input value="Reset" name="resetButton" tabindex="50" type="reset"></p></td>
		</tr>
	</tbody></table>
</form>

</body>
</html>