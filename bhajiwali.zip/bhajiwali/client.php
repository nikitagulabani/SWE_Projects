<?php
$cid=$_GET['cid'];
$type=$_GET['type'];
include 'datalogin.php';
$query = "SELECT * FROM `customer` WHERE CidPhone=$cid";
$rec=mysqli_query($con,$query);
$query1 = "SELECT `Oid`, `Date`,`ATotal`,`Status` FROM `order` WHERE CidPhone=$cid";
$rec1=mysqli_query($con,$query1);
$query2 = "SELECT `Oid`, `Date`,`ATotal`,`Status` FROM `order` WHERE CidPhone=$cid AND Date=(SELECT MAX(`Date`) FROM `order`)";

$rec2=mysqli_query($con,$query2);
while($row2=mysqli_fetch_assoc($rec2))
		{
			
			$oid=$row2['Oid'];
			$odate=$row2['Date'];
			$atotal=$row2['ATotal'];
			
			
		}
	


if ($type=="premium")
{
	
	$query3="SELECT `ADDate`, `Deposit` FROM `advanceddeposit` WHERE advanceddeposit.CidPhone=$cid";
	$rec3=mysqli_query($con,$query3);
}


?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="style/autocomplete.css"/>
<link rel="stylesheet" href="style/jquery-ui.css"/>
<link rel="stylesheet" href="style/jquery-ui.structure.css"/>
<script src="script/jquery.js"></script>
<script src="script/jquery-ui.js"></script>
<script>
$(function(){
	$("#date").datepicker({dateFormat: 'yy-mm-dd'});
});
</script>
<script>
  $(function() {
    $( "#dialog" ).dialog({
      autoOpen: false,
      show: {
        effect: "blind",
        duration: 1000
      },
      hide: {
        effect: "explode",
        duration: 1000
      }
    });
 
    $( "#opener" ).click(function() {
      $( "#dialog" ).dialog( "open" );
    });
  });
  </script>

<script>
function adddeposit(cid){
	var deposit = null;
	var entrydate = null;
	var url = null;
	var xmlhttp = null;
		if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
		if(xmlhttp!=null)
		{
			deposit = document.getElementById("deposit").value;
			entrydate = document.getElementById("date").value;
			
			url = "insertdeposit.php?cid="+cid+"&deposit="+deposit+"&date="+entrydate;
			xmlhttp.open("GET",url,true);
			xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
			xmlhttp.send();
			
		}
		else
		{
			alert("Your browser is not compatible.")
		}
		xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
				document.getElementById("depTable").innerHTML = xmlhttp.responseText;
				document.getElementById("infoDiv").innerHTML = "Deposit Added Successfully";
				document.getElementById("deposit").value="";
				document.getElementById("date").value="";
				location.reload();
				
            }
        };
}
</script>

</head>

<body bgcolor="#FFFFCC">

<h2>BhajiWali-Sabse Fresh</h2>


	<p>Client Information
	<table id="table2" border="0" cellpadding="12px" width="50%">
		<tbody>
		<tr>
		
		<?php
		
		while($row=mysqli_fetch_assoc($rec))
		{
			$cfirst=$row['Cfirst'];
		
			echo"<tr>";
			echo"<td><b>Client ID: </b>".$row['CidPhone']."</a></td>";
			echo"<td><b>Client Type: </b>".$row['Ctype']."</a></td>";
			echo"<td><b>First: </b>" .$row['Cfirst']. "</td>";
			echo"<td><b>Last: </b>" .$row['Clast']. "</td>";
			echo"<td><b>Address: </b>" .$row['CAddress']. "</td>";
			
			
			
			echo"</tr>";
			
		}
		?>
		</tr>

		</table>
		
		
		
		<?php
		if($type=="premium")
		{
			?>
			<form method="GET">
			<table>
			<tr><td>Deposit Amount:</td><td><input type="number" name="deposit" id="deposit"></td></tr>
			<tr><td>Date:</td><td><input type="text" name="date" id="date"></td></tr>
			<tr><td><input type="button" name="add" id="add" onclick="adddeposit(<?php echo $cid; ?>)" value="Add"/><td></tr>
			</table>
			<div id="infoDiv"></div>
		</form>

		
		<br/>
		<br/>
		<hr/>
			<div id="depTable">
			<table id="table4" border="2px" cellpadding="12px" width="50%">
			<caption> Deposit Table </caption>
		<tbody><tr>
			<td><b>Date </b></td>
			<td><b>Deposit</b></td>

		</tr>
		<tr>
			<?php
			$sum=0;
			while($row3=mysqli_fetch_assoc($rec3))
			{
			$d=$row3['Deposit'];
			
			echo"<tr>";
			echo"<td>".$row3['ADDate']."</td>";
			echo"<td>".$d."</td>";
			$sum+=$d;
			echo"</tr>";
			
			}
			echo "</table>";
			echo"<tr><b>Total Deposit:</b>".$sum."</tr>";
			echo"</div>";
			
		}
		
		?>
		 <br/>
		<br/>
		<hr/>
		<br/>
		<br/>
		<table id="table3" border="2px" cellpadding="12px" width="50%">
		<caption> Customer Order Table </caption>
		<tbody><tr>
			<td><b>Order ID </b></td>
			<td><b>Date </b></td>
			<td><b>Total </b></td>
			<td><b>Status</b></td>

		</tr>
		<tr>
		
		<?php
		$totalsales=0;
		while($row1=mysqli_fetch_assoc($rec1))
		{
			
			$atotal=$row1['ATotal'];
			echo"<tr>";
			echo"<td> <a href=\"bill.php?oid=".$row1['Oid']."\">".$row1['Oid']."</a></td>";
			echo"<td>".$row1['Date']."</td>";
			echo"<td>".$atotal. "</td>";
			echo"<td>".$row1['Status']."</td>";
			
			$totalsales+=$atotal;
			echo"</tr>";
			
		}
		echo"</table>";
		$bal=0;
		echo"<div><b>Total Sales:</b>".$totalsales."</div>";
		echo "</br>";
		if($type=="premium")
		{
			$bal=$sum-$totalsales;
		}
		echo"<div id=\"balance\"><b>Balance:</b>".$bal."</div>";
		?>
		

	</tbody></table>
	<p>&nbsp;</p>
	<hr/>
	<p>&nbsp;</p>

<br/>
<div id="dialog" title="Message">
	<?php	
	if($totalsales==0)
	{
	echo "Hello $cfirst,<br/>";
	echo"Availible Balance: <b>$bal</b><br/>";
	echo"Thank You for choosing Bhaji Wali<br/>";	
	}
	else
	{
	echo "Hello $cfirst,<br/>";
	echo"Total for order $oid dated $odate : <b>$atotal</b><br/>";
	echo"Availible Balance: <b>$bal</b><br/>";
	echo"Thank You for choosing Bhaji Wali<br/>";
	}
	?>
</div>
<button id="opener">Message</button>
<a href="admindashboard.php">Go Back</a>
			<br/>
<p>&nbsp;</p>
<p></p>



</body></html>