<?php

include 'datalogin.php';
$query = "SELECT * FROM `order` o, `customer` c where o.Date = Date(NOW()) and o.CidPhone = c.CidPhone";



$rec=mysqli_query($con,$query);

?>
<html>
<head>
 <link rel="stylesheet" href="style/jquery-ui.css"/>
<link rel="stylesheet" href="style/jquery-ui.structure.css"/>
<script src="script/jquery.js"></script>
<script src="script/jquery-ui.js"></script>


<script>
 //button- input & go back
  $(function() {
    $( ".button" )
      .button(
	  //icon applies to anchor and button bot input elements
		{
			icons: {
			primary: "ui-icon ui-icon-arrowreturnthick-1-w"
		},
      text: true
		});
		
  });
</script>
<script>
function printDiv(divName) {
    var printContents = document.getElementById(divName).innerHTML;
    var originalContents = document.body.innerHTML;
    document.body.innerHTML = printContents;
    window.print();
    document.body.innerHTML = originalContents;
}
</script>


<title>Bhaji Wali&nbsp; - Sabse Fresh!</title>
<style>
table, th, td {
	border: 1px solid black;
}
</style>
</head>

<body bgcolor="#FFFFCC">
<div id="printableArea">

<h2>BhajiWali-Sabse Fresh</h2>

<br>
<h4>Daily Supply Form</h4>
<p id="demo"></p>

		<script>
		var dateObj = new Date();
		var month = dateObj.getUTCMonth() + 1; //months from 1-12
		var day = dateObj.getUTCDate();
		var year = dateObj.getUTCFullYear();

		newdate = day + "/" + '0'+ month + "/" + year;
		document.getElementById("demo").innerHTML = "Date:"+" "+newdate;
		</script>


<table>
<tr>
<td>	

		
		<?php
		
		//------------------------------Calculations----------------------------------------------
		$counter = 1;
		$rec1=mysqli_query($con,$query);
		
		while($row=mysqli_fetch_assoc($rec1))
		{
			
			
			//--------------------------Display Info-----------------------------------------
			echo"<table>";
			echo"<tr>";
			//client details
			echo"<td>";
			echo"<br>";
			echo"<b>Order Id:</b>" .$counter;
			echo"<br>";
			echo"<b>Name:</b>" .$row['Cfirst']." ".$row['Clast'];
			echo"<br>";
			echo"<b>Phone No.:</b>" .$row['CidPhone'];
			echo"<br>";
			echo"<b>Address:</b>" .$row['CAddress'];
			echo"</td>";
			
			//Paid
			
			
			echo"<td>";
			echo"<b>Paid:</b>";
			echo"<br>";
			echo"</td>";
			echo"</tr>";
			echo"</tbody>";
			echo"</table>";
		
			$counter++;
		}
		?>
		
		
		
	</td>
	
	</tr>
	</table>
	</div>
	<br/>
	<form>
	<table>
	<tr>
	<td><input type="button" onclick="printDiv('printableArea')" value="PRINT" class="button"/></td>
	<td><a href="admindashboard.php" class="button">Go Back</a></td>
	</tr>
	</table>
</form>
</body></html>