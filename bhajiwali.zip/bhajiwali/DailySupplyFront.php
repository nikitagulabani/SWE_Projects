<?php

include 'datalogin.php';
//to get orders
//2016-04-13
$query = "SELECT * FROM `order` o, `customer` c where o.Date = Date(NOW()) and o.CidPhone = c.CidPhone";

//Outter loop for the orders

 //Query: select * from orderitems where oid = this oid
    //trs for the items

$rec=mysqli_query($con,$query);

?>
<html>
<head>
 <link rel="stylesheet" href="style/jquery-ui.css"/>
<link rel="stylesheet" href="style/jquery-ui.structure.css"/>
<script src="script/jquery.js"></script>
<script src="script/jquery-ui.js"></script>


<script>
 //button- input & go back
  $(function() {
    $( ".button" )
      .button(
	  //icon applies to anchor and button bot input elements
		{
			icons: {
			primary: "ui-icon ui-icon-arrowreturnthick-1-w"
		},
      text: true
		});
		
  });
</script>
<script>
function printDiv(divName) {
    var printContents = document.getElementById(divName).innerHTML;
    var originalContents = document.body.innerHTML;
    document.body.innerHTML = printContents;
    window.print();
    document.body.innerHTML = originalContents;
}
</script>


<title>Bhaji Wali&nbsp; - Sabse Fresh!</title>
<style>
table, th, td {
     border: 1px solid black;
	 
	 
}
</style>
</head>

<body bgcolor="#FFFFCC">
<div id="printableArea">
<h2>BhajiWali-Sabse Fresh</h2>

<br>
		<p id="demo"></p>

		<script>
		var dateObj = new Date();
		var month = dateObj.getUTCMonth() + 1; //months from 1-12
		var day = dateObj.getUTCDate();
		var year = dateObj.getUTCFullYear();

		newdate = day + "/" + '0'+ month + "/" + year;
		document.getElementById("demo").innerHTML = "Date:"+" "+newdate;
		</script>
		<table>
		<tr>
		<td>
		
		<?php
		$counter = 1;
		$rec1=mysqli_query($con,$query);
		
		while($row=mysqli_fetch_assoc($rec1))
		{
			echo "<table><tr><th>Order ID</th><th>Name</th><th>Item Name</th><th>Quantity</th></tr>";
			//$counter = $row['Iid'];
			$orderId = $row['Oid'];
			echo"<tr>";
			echo"<td>" .$counter."</td>";
			echo"<td>" .$row['Cfirst']." ".$row['Clast']. "</td>";
			
			
			$itemQuery = "SELECT * FROM `orderitem` o, `item` i WHERE o.Iid = i.Iid and i.Itype=\"leafy\" and o.Oid = ".$orderId;
			$counterItem = 1;
			$itemList=mysqli_query($con,$itemQuery);
			//echo "<td>Count</td><td>Item Name</td><td>Quantity</td>";
			while($listRow=mysqli_fetch_assoc($itemList))
			{
				echo "<tr><td></td><td></td><td>".$listRow['Iname']."</td>
					  <td>".$listRow['Qty']."</td></tr>";
				$counterItem++;
			}
			echo"</tr>";
			echo "</table>";
			echo "<br/>";
			
			$counter++;
		}
		?>
		
		
		
	</td>
	</tr>
	</table>
	<form>
	<br/>
	</div>
	<table>
	<tr>
	<td><input type="button" onclick="printDiv('printableArea')" value="PRINT" class="button"/></td>
	<td><a href="admindashboard.php" class="button">Go Back</a></td>
	</tr>
	</table>
</form>
</body></html>