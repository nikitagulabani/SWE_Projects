<?php
session_start();

$Sid=$_SESSION["aid"];
$username=$_SESSION["username"];
echo "Welcome $username"." "."<a href='index.php' class=\"button-logout\">Logout</a>";

?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Admin Dashboard</title>
  
	<link rel="stylesheet" href="/resources/demos/style.css">
	<link rel="stylesheet" href="style/jquery-ui.css"/>
	<link rel="stylesheet" href="style/jquery-ui.structure.css"/>
	<script src="script/jquery.js"></script>
	<script src="script/jquery-ui.js"></script>
	<style>
	#dailyTasks{
		width:40%;
	}
	</style>
	 <script>
 //button- logout
  $(function() {
    $( ".button-logout" )
      .button(
	  //icon applies to anchor and button bot input elements
		{
			icons: {
			primary: "ui-icon ui-icon-power"
		},
      text: true
		});
  });
  </script>
  <script>
  $(function() {
	  //tabs
    $( "#tabs" ).tabs({
      beforeLoad: function( event, ui ) {
        ui.jqXHR.fail(function() {
          ui.panel.html(
            "Couldn't load this tab. We'll try to fix this as soon as possible. " +
            "If this wouldn't be a demo." );
        });
      }
    });
  });
  </script>
  <script>
  //menu
  $(function() {
		$( "#dailyTasks" ).menu();
	});
  </script>
 
</head>
<body bgcolor="#FFFFCC">
<div>
 <h4>Perform Daily Tasks<h4>
   <ul  id="dailyTasks">
    <li><a href="DailyOrderFront.php" style="text-decoration:none">Order Form Front</a></li>
    <li><a href="DailyOrderBack.php" style="text-decoration:none">Order Form Back</a></li>
	<li><a href="DailyPurchaseForm.php" style="text-decoration:none">Purchase Form</a></li>
    <li><a href="DailySupplyFront.php" style="text-decoration:none">Supply Form Front</a></li>
	<li><a href="DailySupplyBack.php" style="text-decoration:none">Supply Form Back</a></li>
	
	</ul>
  </div>
 
<div id="tabs">
  <ul>
    <li><a href="#tabs-1">Welcome</a></li>
    <li><a href="registerstaff.php">Register Staff</a></li>
    <li><a href="registercustomer.php">Register Customer</a></li>
	<li><a href="viewclients.php">Client Accounts</a></li>
    <li><a href="uorder.php">Update/Edit Order</a></li>
	<li><a href="vorders.php">View Orders/Bills</a></li>
    <li><a href="vuitems.php">Update Items</a></li>
	
  </ul>
  <div id="tabs-1">
    <p>Bhaji Wali- Sabse Fresh </p>
    <p>Welcome Admin !!!</p>
	<p> You can perform various tasks, by clicking the respective tabs.</p>
</div>
 
 
</body>
</html>