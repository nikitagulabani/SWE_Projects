<?php
include 'datalogin.php';
$cid=$_POST['cidphone'];
$date=$_POST['datepicker'];

$ctype=$_POST['ctype'];

$first=$_POST['first'];
$last=$_POST['last'];
$address=$_POST['address'];
$amount=$_POST['amount'];

$query = "INSERT INTO `customer`(`CidPhone`,`Ctype`, `Cfirst`, `Clast`, `CAddress`,`Comments`) VALUES ($cid,'$ctype','$first','$last','$address','')";
mysqli_query($con,$query);

if($ctype=="premium")
{

	$query1 = "INSERT INTO `advanceddeposit`(`CidPhone`, `ADDate`, `Deposit`) VALUES($cid,'$date',$amount)";

	mysqli_query($con,$query1);
}
$_SESSION['message'] = 'Customer Registered Successfully';
if (isset($_SESSION['message'])) {
  echo $_SESSION['message'];
  unset($_SESSION['message']);
}
mysqli_close($con);
echo "<br/><a href='admindashboard.php'>Register New Customer</a>";
?>
