<?php
$username="root";
$pass="";$database="bhajiwali";
$con = mysqli_connect("localhost","$username","$pass","$database");
mysqli_select_db($con,$database) or die( "Unable to select database");

?>