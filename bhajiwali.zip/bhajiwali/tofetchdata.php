<?php
include 'datalogin.php';
$cid = $_GET['val'];

$query = "SELECT `Cfirst`, `Clast`, `CAddress`FROM `customer` WHERE `CidPhone`='$cid'";
$rec=mysqli_query($con,$query);
$first = null;
$last = null;
$address = null;
while($row=mysqli_fetch_assoc($rec))
		{
			
			$first=$row['Cfirst'];
			$last=$row['Clast'];
			$address=$row['CAddress'];
		}
echo($cid.";".$first.";".$last.";".$address);
mysqli_close($con);

?>
