<?php
session_start();

$date=$_POST['datep'];
$sid=$_POST['sid'];
$cidphone=$_POST['cidphone'];
$GrandTotal=$_POST['total'];
include 'datalogin.php';
$query = "INSERT INTO `order`( `CidPhone`, `Sid`, `Date`, `ETotal`, `ATotal`, `Status`) VALUES ($cidphone,'$sid','$date',$GrandTotal,'','')";
mysqli_query($con,$query);

$query1="SELECT MAX(`Oid`) oid FROM `order`";
$rec=mysqli_query($con,$query1);
while($row=mysqli_fetch_assoc($rec))
		{
			
			$oid=$row['oid'];
		}
	
	
$query2="SELECT * FROM `item`";
$rec1=mysqli_query($con,$query2);
while($row1=mysqli_fetch_assoc($rec1))
		{
			
			$Iid=$row1['Iid'];
			$test = 'q'.$Iid;
			$qty=$_POST[$test];
			if($qty != 0){
				
				$ins="INSERT INTO `orderitem`(`Oid`, `Iid`, `Qty`) VALUES ($oid,$Iid,$qty)";
				mysqli_query($con,$ins);
				
			}
			
		}
		
	//echo ($oid);
$_SESSION['message'] = 'Order Placed Successfully';
if (isset($_SESSION['message'])) {
  echo $_SESSION['message'];
  unset($_SESSION['message']);
}
mysqli_close($con);
?>
<html>
<head>
<link rel="stylesheet" href="style/jquery-ui.css"/>
<link rel="stylesheet" href="style/jquery-ui.structure.css"/>
<script src="script/jquery.js"></script>
<script src="script/jquery-ui.js"></script>
</head>
<body bgcolor="#FFFFCC">
 <script>
 //button- input & go back
  $(function() {
    $( ".button" )
      .button(
	  //icon applies to anchor and button bot input elements
		{
			icons: {
			primary: "ui-icon ui-icon-arrowreturnthick-1-w"
		},
      text: true
		});
  });
  </script>
 <script>
 //button- logout
  $(function() {
    $( ".button-logout" )
      .button(
	  //icon applies to anchor and button bot input elements
		{
			icons: {
			primary: "ui-icon ui-icon-power"
		},
      text: true
		});
  });
  </script>
<br/>
<table>
<tr>
<td><a href="order.php" class="button">Place Another Order</a></td>
<td><a href="index.php" class="button-logout">Logout</a></td>
</tr>
</table>
</body>
</html>