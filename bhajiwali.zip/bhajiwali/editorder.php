<?php
$oid=$_GET['oid'];
include 'datalogin.php';
$query = "SELECT order.CidPhone,`Date`, `Sid`, `ETotal`,`Cfirst`, `Clast`, `CAddress` FROM `order`INNER JOIN`customer` ON customer.CidPhone=order.CidPhone AND order.Oid=$oid";
$rec=mysqli_query($con,$query);
$CidPhone = "";
$odate = "";
$sid = "";
$ETotal = "";
$cfirst = "";
$clast = "";
$Caddress = "";
while($row=mysqli_fetch_assoc($rec))
		{
			$CidPhone = $row['CidPhone'];
			$odate = $row['Date'];
			$sid = $row['Sid'];
			$ETotal = $row['ETotal'];
			$cfirst = $row ['Cfirst'];
			$clast = $row['Clast'];
			$Caddress = $row['CAddress'];
		}

$query1 = "SELECT DISTINCT item.Iid,`Iname`,`IPrice`,`Qty` FROM `orderitem`,`order`,`item` WHERE orderitem.Oid=$oid AND orderitem.Iid=item.Iid";


$rec1=mysqli_query($con,$query1);

$query2 = "SELECT * FROM `item`";

$rec2=mysqli_query($con,$query1);

?>
<html>
<head>
<script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="auto-complete.js"></script>

<script>
function testChange(counter){
	var test = "q"+counter;
	var test2 = "t"+counter;
	var test3 = "p"+counter;
	var quantity = document.getElementById(test).value;
	var price = document.getElementById(test3).value;
	var total = quantity * price;
	document.getElementById(test2).value = total;
	
	var grandtotal = 0.0;
	
	<?php while($row2=mysqli_fetch_assoc($rec2)){
		$testval="";
		$testval = $row2['Iid'];
		//echo $testval;
		?>
		var gt = "t"+ <?php echo $testval; ?>;
		//alert (gt);
		grandtotal += parseFloat(document.getElementById(gt).value);
	<?php
	}
	?>
	document.getElementById("total").value = grandtotal;
	
}
</script>
<title>Bhaji Wali&nbsp; - Sabse Fresh!</title>

</head>

<body bgcolor="#FFFFCC">

<h2>BhajiWali-Sabse Fresh</h2>

<br>
<p>Enter Coustomer Info:</p>

<form method="POST" action="editordersubmit.php" name="ofrm">
<input type="hidden" name="orderid" id="orderid" size="30" tabindex="1" value="<?php echo $oid; ?>" readonly>
	<table id="table1" border="0" cellpadding="0" width="550">
		<tbody>
		<tr>
			<td align="right" width="340">*Date:</font></td>
			<td width="10">&nbsp;</td>
			<td width="200"><input type="date" name="date" id="date" size="30" tabindex="1" value="<?php echo $odate; ?>" readonly></td>
		</tr>
		<tr>
			<td align="right" width="340">*Staff ID:</font></td>
			<td width="10">&nbsp;</td>
			<td width="200"><input type="text" name="sid" id="sid" size="30" tabindex="1" value="<?php echo $sid; ?>" readonly></td>
		</tr>
		<tr>
			<td align="right" width="340">*CID/Phone:</font></td>
			<td width="10">&nbsp;</td>
			<td width="200"><input name="cidphone" size="30" tabindex="1" type="tel" id="cidphone" value="<?php echo $CidPhone; ?>" readonly></td>
		</tr>
		<tr>
			<td align="right" width="340">First:</font></td>
			<td width="10">&nbsp;</td>
			<td width="200"><input name="first" size="30" tabindex="1" type="text" id="first" value="<?php echo $cfirst; ?>" readonly></td>
		</tr>
		<tr>
			<td align="right" width="340">Last:</font></td>
			<td width="10">&nbsp;</td>
			<td width="200"><input name="last" size="30" tabindex="1" type="text" id="last" value="<?php echo $clast; ?>" readonly></td>
		</tr>

		<tr>
			<td align="right" width="340">Address:</td>
			<td width="10">&nbsp;</td>
			<td width="200"><input type="address" size="30" tabindex="1" type="text" id="address" name="address" value="<?php echo $Caddress; ?>" readonly></td>
		</tr>
		<tr>
			<td align="right" width="340">&nbsp;</td>
			<td width="10">&nbsp;</td>
			<td width="200">&nbsp;</td>
		</tr>
	</tbody></table>
	<p>Edit Order:</p>
	<table id="table2" border="0" cellpadding="0" width="550">
		<tbody><tr>
			<td height="31" width="250"><b>Item</b></td>
			<td align="center" height="31" width="100"><b>Qty/Weight</b></td>
			<td align="right" height="31" width="60"><b>Price/Unit </b></td>
			<td align="right" height="31" width="140"><b>Total</b></td>
		</tr>
		<tr>
		<table id="table3">
		<?php
		$counter = 0;
	
		while($row1=mysqli_fetch_assoc($rec1))
		{
			$counter = $row1['Iid'];
			echo"<tr>";
			echo"<td width=\"250\">" .$row1['Iname']. "</td>";
			echo"<td align=\"center\" width=\"100\">
			<input id=\"q$counter\" name=\"q$counter\" class=\"qty\" size=\"5\" tabindex=\"5\" type=\"input\" value=".$row1['Qty']." onchange=\"testChange($counter)\"></td>";
			echo"<td align=\"right\" width=\"60\">
			<input id=\"p$counter\" class=\"price\" size=\"5\" tabindex=\"5\" type=\"input\" value=".$row1['IPrice']."> </td>";
			echo"<td align=\"right\" width=\"140\">
			<input id=\"t$counter\" name=\"ttotal\" size=\"12\" tabindex=\"99\" type=\"text\" value=\"0\" readonly></td>";
			
			echo"</tr>";
			//$counter++;
		}
		?>
		</table>
		
		</tr>
		<tr>
			<td width="250">&nbsp;</td>
			<td align="center" width="100">&nbsp;</td>
			<td align="right" width="60">&nbsp;</td>
			<td align="right" width="140">&nbsp;</td>
		</tr>
		<tr>
		<table>
		<tr>
		<b>
			<td width="250">
			<p align="right"><b>TOTAL:</b></p></td>
			<td align="center" width="100">&nbsp;</td>
			<td align="right" width="60">&nbsp;</td>
			<td align="right" width="140">
			<input id="total" name="total" size="15" tabindex="99" type="text" readonly></td>
			</b>
		</tr>
		</table>
		</tr>
		<tr>
			<td width="250">&nbsp;</td>
			<td align="center" width="100">&nbsp;</td>
			<td align="right" width="60">&nbsp;</td>
			<td align="right" width="140">&nbsp;</td>
		</tr>
	</tbody></table>
	<p>&nbsp;</p>
	<table id="table3" border="0" cellpadding="0" width="550">
		<tbody><tr>
			<td width="563">
			<p align="center">
			<input value="Save" name="subButton" id="subButton" tabindex="50" type="submit">&nbsp;&nbsp;&nbsp;&nbsp; 
			<a href="admindashboard.php">Go Back</a>
			<br/>
		</tr>
	</tbody></table>
</form>


<p>&nbsp;</p>
<p></p>



</body></html>