<?php
$oid=$_GET['oid'];

include 'datalogin.php';
#$query = "SELECT `Oid`,`CidPhone`,`Cfirst`, `Clast`, `CAddress` FROM `order` INNER JOIN `customer` ON customer.CidPhone=order.CidPhone";
$query = "SELECT `Oid`, `Date`, `ETotal`, `ATotal`,`Cfirst`, `Clast`, `CAddress` FROM `order`INNER JOIN`customer` ON customer.CidPhone=order.CidPhone AND order.Oid=$oid";
$query1 = "SELECT DISTINCT `Iname`,`IPrice`,`Qty` FROM `orderitem`,`order`,`item` WHERE orderitem.Oid=$oid AND orderitem.Iid=item.Iid";
$rec=mysqli_query($con,$query);

$rec1=mysqli_query($con,$query1);
$rec2=mysqli_query($con,$query);
?>
<html>
<head>
<script>
function printDiv(divName) {
    var printContents = document.getElementById(divName).innerHTML;
    var originalContents = document.body.innerHTML;
    document.body.innerHTML = printContents;
    window.print();
    document.body.innerHTML = originalContents;
}
</script>

</head>

<body bgcolor="#FFFFCC">
<div id="printableArea">

<h2>BhajiWali-Sabse Fresh</h2>


	<p>Orders:</p>
	<table id="table2" border="0" cellpadding="10px" width="50%">
		<tbody>
		<tr>
		
		<?php
		
		while($row=mysqli_fetch_assoc($rec))
		{
			
			echo"<tr>";
			echo"<td><b>Order ID: </b>".$row['Oid']."</a></td>";
			echo"<td><b>Date: </b>" .$row['Date']. "</td>";
			echo"</tr>";
			echo"<tr>";
			echo"<td><b>First: </b>" .$row['Cfirst']. "</td>";
			echo"<td><b>Last: </b>" .$row['Clast']. "</td>";
			echo"</tr>";
			echo"<td><b>Address: </b>" .$row['CAddress']. "</td>";
			
			
			echo"</tr>";
			
		}
		?>
		</tr>

		</table>
		<br/>
		<br/>
		<hr/>
		<br/>
		<br/>
		<table id="table3" border="2px" cellpadding="12px" width="50%">
		<tbody><tr>
			<td><b>Item Name </b></td>
			<td><b>Price </b></td>
			<td><b>Quantity </b></td>
			<td><b>Total</b></td>

		</tr>
		<tr>
		
		<?php
		
		while($row1=mysqli_fetch_assoc($rec1))
		{
			
			echo"<tr>";
			echo"<td>".$row1['Iname']."</td>";
			echo"<td>".$row1['IPrice']."</td>";
			echo"<td>" .$row1['Qty']. "</td>";
			echo"<td>".$row1['IPrice']*$row1['Qty']."</td>";
			
			
			echo"</tr>";
			
		}
		?>
		</table>
		
		<table id="table4" border="0" cellpadding="0" width="50%">
		<tbody>
			
		
		<?php
		
		while($row2=mysqli_fetch_assoc($rec2))
		{
			
			
			echo"<tr><b>Est Total: </b>" .$row2['ETotal']. "</tr>";
			echo"<tr></tr>";
			echo"<tr><b>Actual Total: </b>" .$row2['ATotal']. "</tr>";
	
			
			
			
		}
		?>
		</table>
		
		
		
		</tr>
		<tr>
			<td width="250">&nbsp;</td>
			<td align="center" width="100">&nbsp;</td>
			<td align="right" width="60">&nbsp;</td>
			<td align="right" width="140">&nbsp;</td>
		</tr>
		<tr>
		
		</tr>
		<tr>
			<td width="250">&nbsp;</td>
			<td align="center" width="100">&nbsp;</td>
			<td align="right" width="60">&nbsp;</td>
			<td align="right" width="140">&nbsp;</td>
		</tr>
	</tbody></table>
	<p>&nbsp;</p>
</div>	
<form>
	<input type="button" onclick="printDiv('printableArea')" value="PRINT BILL" />
	<a href="admindashboard.php">Go Back</a>
<br/>
</form>


<p>&nbsp;</p>
<p></p>



</body></html>