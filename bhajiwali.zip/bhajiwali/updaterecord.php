<?php
include 'datalogin.php';
$uid=$_GET['uid'];
$atotal=$_GET['at'];
$status=$_GET['sta'];

$query = "UPDATE `order` SET `ATotal`=$atotal,`Status`='$status' WHERE `Oid`=$uid";
mysqli_query($con,$query);
mysqli_close($con);
?>