<?php
include 'datalogin.php';
$Iid=$_GET['itemid'];
$iprice=$_GET['ip'];

$query = "UPDATE `item` SET `IPrice`=$iprice WHERE `Iid`=$Iid";
mysqli_query($con,$query);
mysqli_close($con);
?>