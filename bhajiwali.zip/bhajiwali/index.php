<?php 
session_start();
if (isset($_SESSION['username'])) {
   session_destroy();
   echo "<br> You are Logged Out Successufuly!";
}
?> 
<!DOCTYPE html>
<html>
<head>
<title>Bhaji Wali&nbsp; - Sabse Fresh!</title>
<link rel="stylesheet" href="style/jquery-ui.css"/>
<link rel="stylesheet" href="style/jquery-ui.structure.css"/>
<script src="script/jquery.js"></script>
<script src="script/jquery-ui.js"></script>

 <script>
 //button- input & go back
  $(function() {
    $( ".button" )
      .button();
  });
  </script>
 

</head>

<body bgcolor="#FFFFCC">

<h2>BhajiWali-Sabse Fresh</h2>
<h3>An on-demand vegetable delivary portal, right to your doorstep. </h3>
<table style="width:60%" align="center">
  <tr>
    <td><a href="login.php" class="button">
<img border="0" alt="Staff Login" src="img/staff.png" width="300" height="100"></a></td>
    <td><a href="adminlogin.php" class="button">
<img border="0" alt="Admin Login" src="img/admin.png" width="300" height="100"></a></td>		
   
  </tr>
 
</table>
<br/>
<br/>
<hr/>
<footer>
 <p><b>Nikita Gulabani;Copyright&copy;2016 Bhaji Wali<b></p>
</footer>

</body>
</html>

