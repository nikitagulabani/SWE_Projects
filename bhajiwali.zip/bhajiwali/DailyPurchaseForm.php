<?php

include 'datalogin.php';


?>
<html>
<head>
 <link rel="stylesheet" href="style/jquery-ui.css"/>
<link rel="stylesheet" href="style/jquery-ui.structure.css"/>
<script src="script/jquery.js"></script>
<script src="script/jquery-ui.js"></script>


<script>
 //button- input & go back
  $(function() {
    $( ".button" )
      .button(
	  //icon applies to anchor and button bot input elements
		{
			icons: {
			primary: "ui-icon ui-icon-arrowreturnthick-1-w"
		},
      text: true
		});
		
  });
</script>
<script>
function printDiv(divName) {
    var printContents = document.getElementById(divName).innerHTML;
    var originalContents = document.body.innerHTML;
    document.body.innerHTML = printContents;
    window.print();
    document.body.innerHTML = originalContents;
}
</script>


<title>Bhaji Wali&nbsp; - Sabse Fresh!</title>
<style>
table, th, td {
     border: 1px solid black;
	 
	 
}

</style>
</head>

<body bgcolor="#FFFFCC">
<div id="printableArea">
<h2>BhajiWali-Sabse Fresh</h2>

<br>
<p>Orders for Today: </p>

<p id="demo"></p>

		<script>
		var dateObj = new Date();
		var month = dateObj.getUTCMonth() + 1; //months from 1-12
		var day = dateObj.getUTCDate();
		var year = dateObj.getUTCFullYear();

		newdate = day + "/" + '0'+ month + "/" + year;
		document.getElementById("demo").innerHTML = "Date:"+" "+newdate;
		</script>


<table>
<tr>

		
	<td>
	<?php 
	$itemQuery = "SELECT distinct(oi.Iid) Iid, Iname FROM `item` i, `order` o, `orderitem` oi 
				  WHERE o.Date = Date(Now()) and o.Oid = oi.Oid and oi.Iid = i.Iid";
	$listItemsTotal = mysqli_query($con, $itemQuery);
	$counter = 1;
	echo "<table><tr><td>S.no</td><td>Item Name</td><td>Total Quantity</td><td>Rate</td></tr>";
	while($resultForItems = mysqli_fetch_assoc($listItemsTotal)){
		$ItemId = $resultForItems['Iid'];
		
		$QtyQuery = "SELECT sum(Qty) qtysum FROM `item` i, `order` o, `orderitem` oi 
					 WHERE o.Date = Date(Now()) and o.Oid = oi.Oid and oi.Iid = i.Iid and oi.Iid = ".$ItemId;
		
		$quantityToal = mysqli_query($con, $QtyQuery);
		
		while($resultForQty = mysqli_fetch_assoc($quantityToal)){
			$totalQty = $resultForQty['qtysum'];
		}
		echo "<tr><td>$counter</td><td>".$resultForItems['Iname']."</td><td>".ceil($totalQty)."</td><td></td></tr>";
		$counter++;
	}
	?>
	
	</td>
	<tr><td></td><td></td><td>Total Rate:</td><td><td></tr>
	</tr>
	</table>
	</div>
	<br/>
	<form>
	<table>
	<tr>
	<td><input type="button" onclick="printDiv('printableArea')" value="PRINT" class="button"/></td>
	<td><a href="admindashboard.php" class="button">Go Back</a></td>
	</tr>
	</table>
</form>
</body></html>