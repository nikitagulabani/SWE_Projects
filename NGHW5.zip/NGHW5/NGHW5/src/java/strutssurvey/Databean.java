/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package strutssurvey;

/**
 *
 * @author Nikita
 */
public class Databean {
    private double mean = 0.0;
 	 private double standarddev = 0.0;
	public double getMean() {
		return mean;
	}
	public void setMean(double mean) {
		this.mean = mean;
	}
	public double getStandarddev() {
		return standarddev;
	}
	public void setStandarddev(double standarddev) {
		this.standarddev = standarddev;
	}
    
}
