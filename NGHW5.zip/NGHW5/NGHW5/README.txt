Project By:

-Nikita Sanjay Gulabani
  G00912741

url is : http://localhost:8080/NGHW5/

To Execute this Project:

1.Make sure you GMU database is connected and your connected to the internet.
2. Unzip the folder, and import the surveyapp folder in Neatbeans.
3.Right click on tiles or index.html ->Run as ->Server(Tomcat 7.0).
4.Fill in the information in the form, if any error respective errors will be displayed. Correct the errors
5.Submit the form.
6.If the mean < 90, user is directed to simpleack.jsp page, else winnerack.jsp page.
7.On both the pages, you have hyperlinks of studentid in the database, select the studentid that will display the student information from the database.